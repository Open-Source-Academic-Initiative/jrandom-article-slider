<?php
use Joomla\CMS\Helper\ModuleHelper;

require ModuleHelper::getLayoutPath('mod_article_slider');
?>